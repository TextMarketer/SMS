<?php 
	include_once('TMRestClient.php');
	// REPLACE with your Text Marketer API username and password
	$tmClient = new TMRestClient('myuser', 'mypass', 'sandbox');
	// Use 'production' (and change the mobile number) if you want to actually send the SMS
	//$tmClient = new TMRestClient('myuser', 'mypass', 'production');
	try {
		
		$credits = $tmClient->getCredits();
		echo "I have $credits credits.<br />\n";

		if ($credits > 0)
			$result = $tmClient->sendSMS('Hello SMS World!', '447777777777', 'My Name');
		
		echo "Used {$result['credits_used']} credits, message ID {$result['message_id']}<br /><br />\n"; 
		
	} catch (Exception $ex) {
		// handle a possible error
		echo "An error occurred: {$ex->getCode()}, {$ex->getMessage()}";
	}
?>