﻿using System;
using RestAPI;
using System.Collections;

namespace ExampleRestAPI
{
    class Example
    {
        static void Main(string[] args)
        {
            RestClient rClient = new RestClient("myusername", "ypassword", RestClient.ENV_SANDBOX);
            try
            {
                if(rClient.isLoginValid())
                    Console.WriteLine("Login is OK!");

                int credits = rClient.getCredits();
                Console.WriteLine("Account have {0} credits.", credits);

                Hashtable result = rClient.sendSMS("Hello SMS World!", "447777123123", "Hello World", 72, "", "");
                Console.WriteLine("Used {0} Credits, ID:{1}, Status: {2}", result["credits_used"], result["message_id"], result["status"]);
            }
            catch (RestClientException e)
            {
                Console.WriteLine(e.Message);
                foreach (DictionaryEntry de in rClient.getLastErrors())
                    Console.WriteLine("Error {0}: {1}", de.Key, de.Value);
            }

            Console.WriteLine();
            Console.Write("Press ENTER to continue");
            Console.ReadLine();
        }
    }
}
