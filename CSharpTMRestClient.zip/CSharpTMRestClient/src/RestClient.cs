﻿using System;
using System.Collections;
using System.Net;
using System.Text;
using System.Web;
using System.IO;
using System.Xml;
using System.Collections.Generic;

namespace RestAPI {
    /// <summary>
    /// API client to access Text Marketer's RESTful API, allows you to send SMS,
	/// check credits, create accounts, and more.
    /// 
    /// Copyright © 2012 Text Marketer Ltd
    /// 
    /// Client class to access Text Marketer RESTful API
    /// 
    /// v1.2 Added sub-account creation function.
    /// </summary>
    public class RestClient
    {
        private enum HTTPMethod { GET, POST, PUT };

        private const String PROD_URL = "https://www.textmarketer.biz/services/rest/";
        private const String SAND_URL = "http://sandbox.textmarketer.biz/services/rest/";
        private const String APICLIENT = "tm-csharp-";
        private const String VERSION = "1.2";

        private String xmlResponse;
        private Hashtable parameters;
        private Hashtable errors;
        private Boolean production;
        private XmlReaderSettings xmlSettings;

        /// <summary>
        /// Use the sandbox system for testing. The sandbox will not modify your account in any way, but will respond normally to your requests.
        /// </summary>
        public const bool ENV_SANDBOX = false;
        /// <summary>
        /// Use the real production system.
        /// </summary>
        public const bool ENV_PRODUCTION = true;

        /// <summary>
        ///  Constructor for the RestClient class.
        /// </summary>
        /// <param name="username">your API Gateway Username</param>
        /// <param name="password">your API Gateway Password</param>
        /// <param name="env">possible values RestClient.ENV_SANDBOX or RestClient.ENV_PRODUCTION</param>
        /// <example>
        /// RestClient tmClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// </example>
        public RestClient(String username, String password, Boolean env)
        {
            production = env;
            xmlResponse = "";
            errors = new Hashtable();
            parameters = new Hashtable();
            parameters.Add("password", password);
            parameters.Add("username", username);
            parameters.Add("apiClient", APICLIENT + VERSION);

            // Set the XML validation settings.
            xmlSettings = new XmlReaderSettings();
            xmlSettings.DtdProcessing = DtdProcessing.Ignore;
            xmlSettings.ValidationType = ValidationType.DTD;
        }

        /// <summary>
        /// Make a call to TM Rest API Gateway to test if the username and password are correct.
        /// </summary>
        /// <returns>Boolean TRUE if login valid, FALSE if username or password not correct</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     if (rClient.isLoginValid())
        ///         Console.WriteLine("Login is OK!");
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public Boolean isLoginValid()
        {
            restGatewayCall("credits", HTTPMethod.GET, null);
            return true;
        }

        /// <summary>
        /// Get the number of credits currently available on your account.
        /// </summary>
        /// <returns>Integer with the credits currently available on your account.</returns>
        public int getCredits()
        {
            int credits;
                
            String xmlResp = restGatewayCall("credits", HTTPMethod.GET, null);
            using (XmlReader reader = XmlReader.Create(new StringReader(xmlResp), xmlSettings))
            {
                reader.ReadToFollowing("credits");
                credits = reader.ReadElementContentAsInt();
            }
            return credits;
        }

        /// <summary>
        /// Send a text message to the specified recipient.
        /// </summary>
        /// <param name="message">The textual content of the message to be sent. Up to 612 characters from the GSM alphabet. The SMS characters we can support is documented at GSM character set. Please ensure that data is encoded in UTF-8.</param>
        /// <param name="mobile_number">The mobile number of the intended recipient, in international format, e.g. 447777123123. Only one number is allowed. To send a message to multiple recipients, you must call the API for each number.</param>
        /// <param name="originator">A string (up to 11 alpha-numeric characters) or the international mobile number (up to 16 digits) of the sender, to be displayed to the recipient, e.g. 447777123123 for a UK number.</param>
        /// <param name="validity">An integer from 1 to 72, indicating the number of hours during which the message is valid for delivery. Messages which cannot be delivered within the specified time will fail.</param>
        /// <param name="email">Optional. Available to txtUs Plus customers only. Specifies the email address for incoming responses. If you specify an email address, you must specify an originator that is a txtUs Plus number that is on your account, or you will get an error response.</param>
        /// <param name="custom">Optional. An alpha-numeric string, 1-20 characters long, which will be used to 'tag' your outgoing message and will appear in delivery reports, thus facilitating filtering of reports.</param>
        /// <returns>Hash table with keys: message_id, credits_used and status</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     Hashtable result = tmClient.sendSMS("Hello SMS World!", "447777123123", "Hello World", 72, "", "");
        ///     Console.WriteLine("Used {0} Credits, ID:{1}, Status: {2}", result["credits_used"], result["message_id"], result["status"]);
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public Hashtable sendSMS(String message, String mobile_number, String originator, int validity, String email, String custom)
        {
            if (validity < 1 || validity > 72)
                validity = 72;
            if (email == null)
                email = "";
            if (custom == null)
                custom = "";
            Hashtable extraparams = new Hashtable();
            extraparams.Add("message", message);
            extraparams.Add("mobile_number", mobile_number);
            extraparams.Add("originator", originator);
            extraparams.Add("validity", validity.ToString());
            extraparams.Add("email", email);
            extraparams.Add("custom", custom);

            String xmlResp = restGatewayCall("sms", HTTPMethod.POST, extraparams);
            using (XmlReader reader = XmlReader.Create(new StringReader(xmlResp), xmlSettings))
            {
                extraparams.Clear();
                String name;
                while (reader.Read())
                {
                    // Only detect start elements.
                    if (reader.IsStartElement())
                    {
                        name = reader.Name;
                        // Next read will contain text.
                        if (reader.Read())
                            extraparams.Add(name, reader.Value);
                    }
                }
                return extraparams;
            }
        }

        /// <summary>
        /// Transfer credits from one account to another account, using the account number for the target.
        /// </summary>
        /// <param name="quantity">The number of credits to transfer from the source account to the target account.</param>
        /// <param name="target">The account number of the account to transfer the credits to</param>
        /// <returns>Hash table with keys: source_credits_before, source_credits_after, target_credits_before and target_credits_after</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     Hashtable result = rClient.transferCreditsToAccount(3, "902");
        ///     Console.WriteLine("Transfered 3 Credits (have {0} now), to account 902, now with {1} Credits", result["source_credits_after"], result["target_credits_after"]);
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public Hashtable transferCreditsToAccount(int quantity, String target)
        {
            Hashtable extraparams = new Hashtable();
            extraparams.Add("quantity", quantity.ToString());
            extraparams.Add("target", target);

            String xmlResp = restGatewayCall("credits", HTTPMethod.POST, extraparams);
            using (XmlReader reader = XmlReader.Create(new StringReader(xmlResp), xmlSettings))
            {
                extraparams.Clear();
                String name;
                while (reader.Read())
                {
                    // Only detect start elements.
                    if (reader.IsStartElement())
                    {
                        name = reader.Name;
                        // Next read will contain text.
                        if (reader.Read())
                            extraparams.Add(name, reader.Value);
                    }
                }
                return extraparams;
            }
        }

        /// <summary>
        /// Transfer credits from one account to another account, using the account number for the target.
        /// </summary>
        /// <param name="quantity">The number of credits to transfer from the source account to the target account.</param>
        /// <param name="target_username">The username of the account to transfer the credits to.</param>
        /// <param name="target_password">The password of the account to transfer the credits to.</param>
        /// <returns>Hash table with keys: source_credits_before, source_credits_after, target_credits_before and target_credits_after</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     Hashtable result = rClient.transferCreditsToUser(3, "targetusername", "targetuserpass");
        ///     Console.WriteLine("Transfered 3 Credits (have {0} now), to account targetusername, now with {1} Credits", result["source_credits_after"], result["target_credits_after"]);
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public Hashtable transferCreditsToUser(int quantity, String target_username, String target_password)
        {
            Hashtable extraparams = new Hashtable();
            extraparams.Add("quantity", quantity.ToString());
            extraparams.Add("target_username", target_username);
            extraparams.Add("target_password", target_password);

            String xmlResp = restGatewayCall("credits", HTTPMethod.POST, extraparams);
            using (XmlReader reader = XmlReader.Create(new StringReader(xmlResp), xmlSettings))
            {
                extraparams.Clear();
                String name;
                while (reader.Read())
                {
                    // Only detect start elements.
                    if (reader.IsStartElement())
                    {
                        name = reader.Name;
                        // Next read will contain text.
                        if (reader.Read())
                            extraparams.Add(name, reader.Value);
                    }
                }
                return extraparams;
            }
        }

        /// <summary>
        /// Get the availability of a given reply keyword. A reply keyword allows you receive incoming text messages to your account by providing people with a keyword, which they text to the short code 88802, e.g. text 'INFO' to 88802 to see this in action.
        /// </summary>
        /// <param name="keyword">The keyword to check is availability.</param>
        /// <returns>Hash table with keys: available and recycle.</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     Hashtable result = rClient.getKeyword("gold");
        ///     Console.WriteLine("The 'gold' keyword is available ({0}), recycled ({1})", result["available"], result["recycle"]);
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public Hashtable getKeyword(String keyword)
        {
            Hashtable extraparams = new Hashtable();

            String xmlResp = restGatewayCall("keywords/" + HttpUtility.UrlEncode(keyword), HTTPMethod.GET, null);
            using (XmlReader reader = XmlReader.Create(new StringReader(xmlResp), xmlSettings))
            {
                String name;
                while (reader.Read())
                {
                    // Only detect start elements.
                    if (reader.IsStartElement())
                    {
                        name = reader.Name;
                        // Next read will contain text.
                        if (reader.Read())
                            extraparams.Add(name, reader.Value);
                    }
                }
                return extraparams;
            }
        }

        /// <summary>
        /// Get a list of available 'send groups' - pre-defined groups containing a list of mobile numbers to send a message to.
        /// Also lists 'stop groups' - numbers in these groups will never be sent messages.
        /// Every account has at least one stop group, so that your recipients can always opt out of receiving messages from you. This is a legal requirement.
        /// </summary>
        /// <returns>Hash table array, each hash table with keys: id, numbers, name and is_stop.</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     Hashtable[] result = rClient.getGroups();
        ///     foreach (Hashtable group in result) {
        ///         Console.WriteLine("Group ID: {0}", group["id"]);
        ///         Console.WriteLine("Group numbers: {0}", group[""]);
        ///         Console.WriteLine("Group name: {0}", group["name"]);
        ///         Console.WriteLine("Group IS STOP: {0}", group["is_stop"]);
        ///     }
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public Hashtable[] getGroups()
        {
            String xmlResp = restGatewayCall("groups", HTTPMethod.GET, null);
            List<Hashtable> groups = new List<Hashtable>();
            using (XmlReader reader = XmlReader.Create(new StringReader(xmlResp), xmlSettings))
            {
                String name;
                while (reader.Read())
                {
                    // Only detect start elements.
                    if (reader.IsStartElement())
                    {
                        name = reader.Name;
                        if (name.Equals("group"))
                        {
                            Hashtable group = new Hashtable();
                            string attribute = reader["name"];
                            if (attribute != null) group.Add("name", attribute);
                            attribute = reader["numbers"];
                            if (attribute != null) group.Add("numbers", attribute);
                            attribute = reader["id"];
                            if (attribute != null) group.Add("id", attribute);
                            attribute = reader["is_stop"];
                            if (attribute != null) group.Add("is_stop", attribute);
                            groups.Add(group);
                        }

                    }
                }
                return groups.ToArray();
            }
        }

        /// <summary>
        /// Get all the numbers in the group, if there are any.
        /// </summary>
        /// <param name="group">Group name or group ID to get the numbers of</param>
        /// <returns>array of String with the numbers of the group</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     Hashtable[] result = rClient.getGroup("directors");
        ///     foreach (String number in result)
        ///         Console.WriteLine("Number {0}", number);
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public String[] getGroup(String group)
        {
            String xmlResp = restGatewayCall("group/" + HttpUtility.UrlEncode(group), HTTPMethod.GET, null);
            List<String> numbers = new List<String>();
            using (XmlReader reader = XmlReader.Create(new StringReader(xmlResp), xmlSettings))
            {
                while (reader.ReadToFollowing("number"))
                {
                    // Next read will contain text.
                    if (reader.Read())
                        numbers.Add(reader.Value);
                }
                return numbers.ToArray();
            }
        }

        /// <summary>
        /// Add a number/numbers to a 'send group' (excluding 'merge' groups).
        /// </summary>
        /// <param name="group">group name or group ID to add the numbers to</param>
        /// <param name="numbers">numbers The MSISDN (mobile number) you wish to add, if you want to add more then one use a comma delimited list</param>
        /// <returns>Return the number of added numbers to the selected group</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     int  result = rClient.addNumbersToGroup("My Group", "447777000001,447777000002,44777700000");
        ///     Console.WriteLine("Added {0} numbers to My Group", result);
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public int addNumbersToGroup(String group, String numbers)
        {
            Hashtable extraparams = new Hashtable();
            extraparams.Add("numbers", numbers);

            String xmlResp = restGatewayCall("group/" + HttpUtility.UrlEncode(group), HTTPMethod.POST, extraparams);
            using (XmlReader reader = XmlReader.Create(new StringReader(xmlResp), xmlSettings))
            {
                int added = 0;
                while (reader.ReadToFollowing("added"))
                {
                    added = int.Parse(reader["quantity"]);
                    return added;
                }
            }
            return 0;
        }

        /// <summary>
        /// Create a new group.
        /// </summary>
        /// <param name="group">the new Group name to be created</param>
        /// <returns>eturn true if the group is added with success</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     if (rClient.addGroup("New Group"))
        ///         Console.WriteLine("'New Group' added with success.");
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public Boolean addGroup(String group)
        {
             String xmlResp = restGatewayCall("group/" + HttpUtility.UrlEncode(group), HTTPMethod.PUT, null);
             return true;
        }

        /// <summary>
        /// Retrieve a list of available delivery report names.
        /// </summary>
        /// <returns>String array with all the reports names</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     String[] result = rClient.getDeliveryReports();
        ///     foreach (String report in result)
        ///         Console.WriteLine("Report name: {0}", report);
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public String[] getDeliveryReports()
        {
            String xmlResp = restGatewayCall("deliveryReports", HTTPMethod.GET, null);
            List<String> numbers = new List<String>();
            using (XmlReader reader = XmlReader.Create(new StringReader(xmlResp), xmlSettings))
            {
                while (reader.ReadToFollowing("report"))
                    numbers.Add(reader["name"]);
                return numbers.ToArray();
            }
        }

        /// <summary>
        /// Retrieve individual delivery report shows the current known status of all messages sent on a given day, or for a particular campaign.
        /// Whereas the function getDeliveryReports() gets a list of available delivery report names, including delivery reports for campaigns.
        /// </summary>
        /// <param name="name">Name of the delivery report to retrieve or 'all' to retrieve all campaign/API report data</param>
        /// <returns>DeliveryReport object array</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     DeliveryReport[] reports = rClient.getDeliveryReport("all");
        ///     foreach (DeliveryReport report in reports) {
        ///     Console.WriteLine(report);
        ///     foreach (Hashtable row in report.Rows) {
        ///         Console.WriteLine("\tMessage ID: {0}", row["message_id"]);
        ///         Console.WriteLine("\tLast Updated: {0}", row["last_updated"]);
        ///         Console.WriteLine("\tMobile Number: {0}", row["mobile_number"]);
        ///         Console.WriteLine("\tStatus: {0}", row["status"]);
        ///         Console.WriteLine("\tCustom {0}", row["custom"]);
        ///     }
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public DeliveryReport[] getDeliveryReport(String name)
        {
            String xmlResp = restGatewayCall("deliveryReport/" + HttpUtility.UrlEncode(name), HTTPMethod.GET, null);
            return parseDeliveryReport(xmlResp);
        }

        /// <summary>
        /// Retrieve individual delivery report shows the current known status of all messages sent on a given day, or for a particular campaign.
        /// Whereas the function getDeliveryReports() gets a list of available delivery report names, including delivery reports for campaigns.
        /// </summary>
        /// <param name="name">Name of the delivery report to retrieve or 'all' to retrieve all campaign/API report data</param>
        /// <param name="custom">Can specify a custom 'tag', which will restrict the search to those messages</param>
        /// <returns>DeliveryReport object array</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     DeliveryReport[] reports = rClient.getDeliveryReport("all", "test");
        ///     foreach (DeliveryReport report in reports) {
        ///     Console.WriteLine(report);
        ///     foreach (Hashtable row in report.Rows) {
        ///         Console.WriteLine("\tMessage ID: {0}", row["message_id"]);
        ///         Console.WriteLine("\tLast Updated: {0}", row["last_updated"]);
        ///         Console.WriteLine("\tMobile Number: {0}", row["mobile_number"]);
        ///         Console.WriteLine("\tStatus: {0}", row["status"]);
        ///         Console.WriteLine("\tCustom {0}", row["custom"]);
        ///     }
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public DeliveryReport[] getDeliveryReport(String name, String custom)
        {
            String xmlResp = restGatewayCall("deliveryReport/" + HttpUtility.UrlEncode(name) + "/custom/" + HttpUtility.UrlEncode(custom), HTTPMethod.GET, null);
            return parseDeliveryReport(xmlResp);
        }

        /// <summary>
        /// Retrieve individual delivery report shows the current known status of all messages sent on a given day, or for a particular campaign.
        /// Whereas the function getDeliveryReports() gets a list of available delivery report names, including delivery reports for campaigns.
        /// </summary>
        /// <param name="name">Name of the delivery report to retrieve or 'all' to retrieve all campaign/API report data</param>
        /// <param name="start">Get delivery report from start DateTime</param>
        /// <param name="end">Get delivery report to end DateTime</param>
        /// <returns>DeliveryReport object array</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     DeliveryReport[] reports = rClient.getDeliveryReport("all", new DateTime(2012, 1, 1), DateTime.Today);
        ///     foreach (DeliveryReport report in reports) {
        ///     Console.WriteLine(report);
        ///     foreach (Hashtable row in report.Rows) {
        ///         Console.WriteLine("\tMessage ID: {0}", row["message_id"]);
        ///         Console.WriteLine("\tLast Updated: {0}", row["last_updated"]);
        ///         Console.WriteLine("\tMobile Number: {0}", row["mobile_number"]);
        ///         Console.WriteLine("\tStatus: {0}", row["status"]);
        ///         Console.WriteLine("\tCustom {0}", row["custom"]);
        ///     }
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public DeliveryReport[] getDeliveryReport(String name, DateTime start, DateTime end)
        {
            String xmlResp = restGatewayCall("deliveryReport/" + HttpUtility.UrlEncode(name) + "/" + HttpUtility.UrlEncode(start.ToString("yyyy-MM-dd'T'HH:mm:ssz")) + "/" + HttpUtility.UrlEncode(end.ToString("yyyy-MM-dd'T'HH:mm:ssz")), HTTPMethod.GET, null);
            return parseDeliveryReport(xmlResp);
        }

        /// <summary>
        /// Retrieve individual delivery report shows the current known status of all messages sent on a given day, or for a particular campaign.
        /// Whereas the function getDeliveryReports() gets a list of available delivery report names, including delivery reports for campaigns.
        /// </summary>
        /// <param name="name">Name of the delivery report to retrieve or 'all' to retrieve all campaign/API report data</param>
        /// <param name="custom">Can specify a custom 'tag', which will restrict the search to those messages</param>
        /// <param name="start">Get delivery report from start DateTime</param>
        /// <param name="end">Get delivery report to end DateTime</param>
        /// <returns>DeliveryReport object array</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     DeliveryReport[] reports = rClient.getDeliveryReport("all", "test", new DateTime(2012, 1, 1), DateTime.Today);
        ///     foreach (DeliveryReport report in reports) {
        ///     Console.WriteLine(report);
        ///     foreach (Hashtable row in report.Rows) {
        ///         Console.WriteLine("\tMessage ID: {0}", row["message_id"]);
        ///         Console.WriteLine("\tLast Updated: {0}", row["last_updated"]);
        ///         Console.WriteLine("\tMobile Number: {0}", row["mobile_number"]);
        ///         Console.WriteLine("\tStatus: {0}", row["status"]);
        ///         Console.WriteLine("\tCustom {0}", row["custom"]);
        ///     }
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public DeliveryReport[] getDeliveryReport(String name, String custom, DateTime start, DateTime end)
        {
            String xmlResp = restGatewayCall("deliveryReport/" + HttpUtility.UrlEncode(name) + "/custom/" + HttpUtility.UrlEncode(custom) + "/" + HttpUtility.UrlEncode(start.ToString("yyyy-MM-dd'T'HH:mm:ssz")) + "/" + HttpUtility.UrlEncode(end.ToString("yyyy-MM-dd'T'HH:mm:ssz")), HTTPMethod.GET, null);
            return parseDeliveryReport(xmlResp);
        }

        /// <summary>
        /// Create a new account (requires additional permissions on your account, please contact Text Marketer to apply)
        /// </summary>
        /// <param name="companyName">The company name for the new account owner</param>
        /// <param name="notificationMobile">(Optional*) the mobile number of the account (*required if $notificationEmail is not set)</param>
        /// <param name="notificationEmail">(Optional*) the email address of the account (*required if $notificationMobile is not set)</param>
        /// <param name="username">(Optional) the username you wish to set on the new account - the API username will be the same</param>
        /// <param name="password">(Optional) the password you wish to set on the new account - the API password will be the same</param>
        /// <param name="promoCode">(Optional) a promotional code entitling the account to extra credits</param>
        /// <param name="overrideRates">If set to true, use the credits rates set on your main account (the account used to access the API), rather than the Text Marketer defaults.</param>
        /// <returns>Hash table with keys: account_id, company_name, create_date, credits, notification_email, notification_mobile, username, api_username and api_password</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     Hashtable result = rClient.createSubAccount("my subaccount", "44123456789", null, "subusername", "subpassword", null, false);
        ///     Console.WriteLine("Account ID: {0}", result["account_id"]);
        ///     Console.WriteLine("Company Name: {0}", result["company_name"]);
        ///     Console.WriteLine("Create Date: {0}", result["create_date"]);
        ///     Console.WriteLine("Credits: {0}", result["credits"]);
        ///     Console.WriteLine("Notification Email: {0}", result["notification_email"]);
        ///     Console.WriteLine("Notification Mobile: {0}", result["notification_mobile"]);
        ///     Console.WriteLine("Username: {0}", result["username"]);
        ///     Console.WriteLine("Password: {0}", result["password"]);
        ///     Console.WriteLine("API Username: {0}", result["api_username"]);
        ///     Console.WriteLine("API Password: {0}", result["api_password"]);
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public Hashtable createSubAccount(String companyName, String notificationMobile, String notificationEmail, 
            String username, String password, String promoCode, Boolean overrideRates)
        {
            Hashtable extraparams = new Hashtable();
            extraparams.Add("company_name", companyName);
            if(notificationMobile != null)
                extraparams.Add("notification_mobile", notificationMobile);
            if(notificationEmail != null)
                extraparams.Add("notification_email", notificationEmail);
            if(username != null)
                extraparams.Add("account_username", username);
            if(password != null)
                extraparams.Add("account_password", password);
            if(promoCode != null)
                extraparams.Add("promo_code", promoCode);
            extraparams.Add("override_pricing", overrideRates);

            String xmlResp = restGatewayCall("account/sub", HTTPMethod.POST, extraparams);
            using (XmlReader reader = XmlReader.Create(new StringReader(xmlResp), xmlSettings))
            {
                extraparams.Clear();
                String name;
                reader.ReadToFollowing("account");
                while (reader.Read())
                {
                    // Only detect start elements.
                    if (reader.IsStartElement())
                    {
                        name = reader.Name;
                        // Next read will contain text.
                        if (reader.Read())
                            extraparams.Add(name, reader.Value);
                    }
                }
                return extraparams;
            }
        }

        /// <summary>
        /// Store the last xml string returned from the last RestClient call
        /// </summary>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     rClient.getGroup("directors");
        ///     Console.WriteLine(rClient.Xml);
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        /// }
        /// </example>
        public String Xml
        {
            get { return xmlResponse; }
        }

        /// <summary>
        /// Return the last error code raised from the last RestClient call
        /// </summary>
        /// <returns>Error code integer or 0 if there is no error</returns>
        public int getLastErrorCode()
        {
            foreach (DictionaryEntry de in errors)
                return (int)de.Key;
            return 0;
        }

        /// <summary>
        /// Return the last error message raised from the last RestClient call
        /// </summary>
        /// <returns>Error message String or "" if there is no error</returns>
        public String getLastErrorMessage()
        {
            foreach (DictionaryEntry de in errors)
                return (String)de.Value;
            return "";
        }

        /// <summary>
        /// Return the all the errors raised from the last RestClient call
        /// </summary>
        /// <returns>Hashtable with all the errors codes and messages</returns>
        /// <example>
        /// RestClient rClient = new RestClient("myuser", "mypass", RestClient.ENV_SANDBOX);
        /// try {
        ///     int credits = rClient.getCredits();
        ///     Console.WriteLine("Account have " + credits + " credits.");
        /// } catch (RestClientException e) {
        ///     Console.WriteLine(e.Message);
        ///     foreach (DictionaryEntry de in rClient.getLastErrors())
        ///         Console.WriteLine("Error {0}: {1}", de.Key, de.Value);
        /// }
        /// </example>
        public Hashtable getLastErrors()
        {
            return errors;
        }

        /// <summary>
        /// Make the HTTP call to the REST API
        /// </summary>
        /// <param name="service">e.g. credits, sms, group, etc..</param>
        /// <param name="method">HTTP method to use: PUT, GET, POST...</param>
        /// <param name="extraparams">Extra vars to add to the HTTP call</param>
        /// <returns></returns>
        private String restGatewayCall(String service, HTTPMethod method, Hashtable extraparams)
        {
            WebRequest request;
            WebResponse response;
            Stream dataStream;
            String url;

            if (production)
                url = PROD_URL + service;
            else
                url = SAND_URL + service;

            StringBuilder strparams = new StringBuilder();
            // Add class params
            foreach (DictionaryEntry de in parameters)
                strparams.AppendFormat("{0}={1}&", de.Key, HttpUtility.UrlEncode(de.Value.ToString()));
            // Add extra params
            if (extraparams != null)
                foreach (DictionaryEntry de in extraparams)
                    strparams.AppendFormat("{0}={1}&", de.Key, HttpUtility.UrlEncode(de.Value.ToString()));

            if (method == HTTPMethod.GET || method == HTTPMethod.PUT)
                url += "?" + strparams;

            request = WebRequest.Create(url);
            request.Method = method.ToString();

            if (method == HTTPMethod.POST)
            {
                byte[] byteArray = Encoding.UTF8.GetBytes(strparams.ToString());
                // Set the ContentType property of the WebRequest.
                request.ContentType = "application/x-www-form-urlencoded";
                // Set the ContentLength property of the WebRequest.
                request.ContentLength = byteArray.Length;
                // Get the request stream.
                dataStream = request.GetRequestStream();
                // Write the data to the request stream.
                dataStream.Write(byteArray, 0, byteArray.Length);
                // Close the Stream object.
                dataStream.Close();
            }
            try
            {
                // Get the response.
                response = request.GetResponse();
                // Get the stream containing content returned by the server.
                dataStream = response.GetResponseStream();
                // Open the stream using a StreamReader for easy access.
                StreamReader reader = new StreamReader(dataStream);
                // Read the content.
                xmlResponse = reader.ReadToEnd();

                // Clean up the streams.
                reader.Close();
                dataStream.Close();
                response.Close();
            }
            catch (WebException e)
            {
                HttpWebResponse httpresp = (HttpWebResponse)e.Response;
                dataStream = httpresp.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                xmlResponse = reader.ReadToEnd();
                dataStream.Close();
                httpresp.Close();

                errors.Clear();
                // Code 400
                if (httpresp.StatusCode == HttpStatusCode.BadRequest)
                {
                    using (XmlReader xmlReader = XmlReader.Create(new StringReader(xmlResponse), xmlSettings))
                    {
                        String code;
                        while (xmlReader.ReadToFollowing("error"))
                        {
                            code = xmlReader["code"];
                            // Next read will contain text.
                            if (xmlReader.Read())
                                errors.Add(code, xmlReader.Value);
                        }
                    }
                    throw new RestClientException(e.Message, e);
                }
                else
                {
                    errors.Add((int)httpresp.StatusCode, httpresp.StatusDescription);
                    throw new RestClientException(e.Message, e);
                }

            }
            return xmlResponse;
        }

        /// <summary>
        /// Parse Delivery Reports xml string and return a array of DeliveryReport Objects
        /// </summary>
        /// <param name="xmlResp"></param>
        /// <returns></returns>
        private DeliveryReport[] parseDeliveryReport(String xmlResp)
        {
            List<DeliveryReport> reports = new List<DeliveryReport>();
            using (XmlReader reader = XmlReader.Create(new StringReader(xmlResp), xmlSettings))
            {
                DeliveryReport report = null;
                while (reader.Read())
                {
                    // Only detect start elements.
                    if (reader.IsStartElement())
                    {
                        if (reader.Name.Equals("report"))
                        {
                            if(report != null)
                                reports.Add(report);
                            report = new DeliveryReport(reader["name"], reader["last_updated"], reader["extension"]);
                        }
                        if (reader.Name.Equals("reportrow"))
                            report.addRow(reader["last_updated"], reader["mobile_number"], reader["message_id"], reader["status"], reader["custom"]);
                    }
                    
                }
                if (report != null)
                    reports.Add(report);
                return reports.ToArray();
            }
        }
    }

    /// <summary>
    /// RestClientException
    /// </summary>
    public class RestClientException : ApplicationException {
        /// <summary>
        /// Initializes a new instance of the RestClientException class.
        /// </summary>
        public RestClientException() : base() {}
        /// <summary>
        /// Initializes a new instance of the RestClientException class with the specified error message.
        /// </summary>
        /// <param name="message">Error message</param>
        public RestClientException(string message) : base(message) {}
        /// <summary>
        /// Initializes a new instance of the RestClientException class with the specified error message and nested exception.
        /// </summary>
        /// <param name="message">Error message</param>
        /// <param name="inner">Nested exception</param>
        public RestClientException(string message, System.Exception inner) : base (message, inner) { }

        // Constructor needed for serialization 
        // when exception propagates from a remoting server to the client.
#pragma warning disable 1591
        protected RestClientException(System.Runtime.Serialization.SerializationInfo info,
            System.Runtime.Serialization.StreamingContext context) 
        {}
    }

    /// <summary>
    /// DeliveryReport Class represent a delivery report status from a sent SMS message
    /// </summary>
    public class DeliveryReport
    {
        private String name;
        private DateTime lastUpdate;
        private String extension;
        private List<Hashtable> rows;

        /// <summary>
        /// Constructor for the DeliveryReport class.
        /// </summary>
        /// <param name="name">Report name</param>
        /// <param name="lastUpdate">Date of the last report update</param>
        /// <param name="extension">extension of the report file, e.g. csv</param>
        public DeliveryReport(String name, DateTime lastUpdate, String extension) {
            this.name = name;
            this.lastUpdate = lastUpdate;
            this.extension = extension;
            rows = new List<Hashtable>();
        }

        public DeliveryReport(String name, String lastUpdate, String extension) : this(name, DateTime.Parse(lastUpdate), extension) {}

        public DeliveryReport() : this ("", new DateTime(), "") {}

        /// <summary>
        /// Delivery Report Name
        /// </summary>
        public String Name {
            get { return name; }
        }

        /// <summary>
        /// Date of the last report update
        /// </summary>
        public DateTime LastUpdate {
            get { return lastUpdate; }
        }

        /// <summary>
        /// Extension of the report file, e.g. csv
        /// </summary>
        public String Extension
        {
            get { return extension; }
        }

        /// <summary>
        /// Return report rows for this Delivery Report
        /// </summary>
        public Hashtable[] Rows {
            get { return rows.ToArray(); }
        }

        /// <summary>
        /// Add report row for this Delivery Report
        /// </summary>
        /// <param name="last_updated">Date of the last row update</param>
        /// <param name="mobile_number">Report mobile number</param>
        /// <param name="message_id">Message unique identifier</param>
        /// <param name="status">Message status</param>
        /// <param name="custom">User custom tag</param>
        public void addRow(String last_updated, String mobile_number, String message_id, String status, String custom)
        {
            Hashtable row = new Hashtable();
            row.Add("last_updated", last_updated);
            row.Add("mobile_number", mobile_number);
            row.Add("message_id", message_id);
            row.Add("status", status);
            row.Add("custom", custom);
            rows.Add(row);
        }

        /// <summary>
        /// Convert deliveryReport to String
        /// </summary>
        /// <returns>String representing of DeliveryReport object</returns>
        public override String ToString()
        {
            return "DeliveryReport [name=" + name + ", lastUpdate=" + lastUpdate + ", extension=" + extension + "]";
        }
    }
}
